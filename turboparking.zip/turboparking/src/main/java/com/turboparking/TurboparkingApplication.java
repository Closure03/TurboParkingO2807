package com.turboparking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TurboparkingApplication {

	public static void main(String[] args) {
		SpringApplication.run(TurboparkingApplication.class, args);
	}

}
